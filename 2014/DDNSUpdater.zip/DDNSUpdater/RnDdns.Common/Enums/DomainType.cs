﻿namespace RnDdns.Common.Enums
{
    public enum DomainType
    {
        DDNS
    }
}
