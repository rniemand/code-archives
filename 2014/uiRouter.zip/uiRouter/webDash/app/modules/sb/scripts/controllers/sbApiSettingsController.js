(function () {
    var app = angular.module('wdCommon');

    app.controller('sbApiSettingsController', [
        function () {
            console.log('sbApiSettingsController');
        }
    ]);
}());
