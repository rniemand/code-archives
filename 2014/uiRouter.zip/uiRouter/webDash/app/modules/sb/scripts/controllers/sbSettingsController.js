(function () {
    var app = angular.module('wdCommon');

    app.controller('sbSettingsController', [
        function () {
            console.log('sbSettingsController');
        }
    ]);
}());
