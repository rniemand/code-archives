﻿(function () {
    var app = angular.module('wdCommon', []);
}());