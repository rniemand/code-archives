﻿(function(exports) {
    exports.webDash = {
        models: {},
        exceptions: {}
    };
}(window));