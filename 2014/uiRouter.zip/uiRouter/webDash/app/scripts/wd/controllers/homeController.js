﻿(function () {
    var app = angular.module('webDash');

    app.controller('homeController', [
        '$state',
        function ($state) {

        }
    ]);
}());