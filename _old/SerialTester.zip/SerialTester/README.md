# SerialTester
Simple tool for issuing commands to / from Arduino projects (or anything that makes use of serial communication)

Source code for the project can be found [here](https://github.com/rniemand/SerialTester).

<!--(Rn.BuildScriptHelper){
	"version": "1.0.107",
	"replace": true
}(END)-->