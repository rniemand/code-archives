﻿namespace Rn.Common.Interfaces
{
    public interface ILogger
    {
        void Debug(string message);
    }
}
