﻿namespace Rn.Common.Interfaces
{
    public interface IWebClient
    {
        string DownloadAsString(string url);
    }
}
