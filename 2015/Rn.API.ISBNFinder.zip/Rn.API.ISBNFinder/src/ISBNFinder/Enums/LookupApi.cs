﻿namespace Rn.API.ISBNFinder.Enums
{
    public enum LookupApi
    {
        ISBNDB = 1
    }
}
