﻿namespace Rn.API.TVDB.Models
{
    public class TVDBClientConfig
    {
        public string APIKey { get; set; }
        public string XmlMirror { get; set; }
        public string BannerMirror { get; set; }
        public string ZipMirror { get; set; }
    }
}
