﻿namespace RnCore.Logging
{
    public enum LoggerSeverity
    {
        Debug,
        Informational,
        Warning,
        Error
    }
}
