﻿namespace RnCore.Enums
{
    public enum LoggerType
    {
        LogFile,
        Console,
        EventLog,
        Unknown
    }
}
