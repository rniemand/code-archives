﻿namespace RnCore.Logging
{
    public enum LoggerType
    {
        Unknown,
        Console,
        LogFile
    }
}
