﻿namespace FtpSync.Enums
{
    public enum FtpFileConstructorSource
    {
        LocalFile,
        RemoteFile
    }
}
