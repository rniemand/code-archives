﻿using Rn.WebManLib.Interfaces;

namespace Rn.WebManLib
{
    public class Services : IServices
    {
        public string HelloWorld()
        {
            return "Hello World";
        }
    }
}
