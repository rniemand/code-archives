﻿namespace RnSync.Syncer
{
  enum SyncEngineState
  {
    Uninitilized,
    NoSourceDefined,
    NoDestinationsDefined,
    Ready
  }
}
