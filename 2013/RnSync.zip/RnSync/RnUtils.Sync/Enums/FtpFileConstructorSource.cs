﻿namespace RnUtils.Sync.Enums
{
    public enum FtpFileConstructorSource
    {
        LocalFile,
        RemoteFile
    }
}
