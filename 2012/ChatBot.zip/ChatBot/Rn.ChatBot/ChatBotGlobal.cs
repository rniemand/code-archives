﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Rn.ChatBot
{
    public static class ChatBotGlobal
    {
        public static bool ChatLogIncomming { get; set; }
        public static bool ChatLogOutgoing { get; set; }
    }
}
