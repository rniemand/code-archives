﻿namespace RnCore.Enums
{
    public enum LoggerSeverity
    {
        Debug,
        Informational,
        Warning,
        Error
    }
}
