﻿namespace RnCore.Logging
{
    public enum LoggerType
    {
        LogFile,
        Console,
        EventLog,
        Unknown
    }
}
