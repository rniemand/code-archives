﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Rn.Core.DB
{
    public class StoredProc
    {

        public StoredProc(string filePath)
        {
            
        }

    }
}
