﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Rn.Db
{
    public enum DBParamType
    {
        Varchar
    }
}