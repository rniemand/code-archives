﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Rn.Logging
{
    public enum Severity
    {
        Error,
        Warning,
        Information,
        Debug
    }
}
