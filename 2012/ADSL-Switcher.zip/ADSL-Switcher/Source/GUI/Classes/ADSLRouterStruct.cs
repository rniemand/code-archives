namespace AdslSwitcher2.Classes
{
    struct ADSLRouterStruct
    {
        public string RouterIP { get; set; }
        public string RouterLoginUser { get; set; }
        public string RouterLoginPass { get; set; }
    }
}
