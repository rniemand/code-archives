namespace AdslSwitcher2.Classes
{
    public struct ADSLAccountStruct
    {
        public string DisplayName { get; set; }
        public string UserName { get; set; }
        public string UserPass { get; set; }
        public bool DefaultAccount { get; set; }
    }
}
