﻿namespace MfLib.Enums
{
    public enum AlbumStatus
    {
        Official,
        Promotion,
        Unknown,
        NotSet
    }
}
