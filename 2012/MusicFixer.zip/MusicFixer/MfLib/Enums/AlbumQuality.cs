﻿namespace MfLib.Enums
{
    public enum AlbumQuality
    {
        Normal,
        Unknown,
        NotSet
    }
}
