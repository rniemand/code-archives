﻿namespace MfLib.Enums
{
    public enum ArtistType
    {
        Unknown,
        Group,
        Person
    }
}
